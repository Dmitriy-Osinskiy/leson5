import Foundation



enum engineCar: String{
    case petrol = "бензиновый"
    case diselEngine = "дизельный"
    case electric = "электрический"
    case hybrid = "гибридный"
}

enum carIgnition: String{
    case On = "Автомобиль заведён"
    case Off = "Автомобиль заглушен"
}

enum doors: String{
    case On = "Открыты"
    case Off = "Заблокированны"

}


protocol OnCar{
    var carBrand: String {get set}
    var carModel: String {get set}
    var yearOfRelease: Int {get set}
    var engine: engineCar {get set}
    var door: doors {get set}
    var ignitionSwitch: carIgnition {get set}
    

}

extension OnCar{
    func action() {
      print ("Автомобиль не завёлся!")
    }
}




class Car: OnCar{
    var carBrand: String
    var carModel: String
    var yearOfRelease: Int
    var engine: engineCar
    var door: doors
    var ignitionSwitch: carIgnition
    
    func action(statusIgnation: carIgnition) {

        if statusIgnation == carIgnition.Off {
            door  = doors.On
            print(" \(ignitionSwitch.rawValue). Двери \(door.rawValue) ")
        } else {
            door = doors.Off
            print(" \(ignitionSwitch.rawValue). Двери \(door.rawValue) ")
        }

    }

    
    init(carBrand:String, carModel: String, yearOfRelease: Int, engine: engineCar, door: doors, ignitionSwitch: carIgnition){
            self.carBrand = carBrand
            self.carModel = carModel
            self.yearOfRelease = yearOfRelease
            self.engine = engine
            self.door = door
            self.ignitionSwitch = ignitionSwitch
    
    }
}




extension Car{
    func action2 (actionIgnation: carIgnition) {
        switch actionIgnation {
                   case .On :
                       ignitionSwitch = actionIgnation
                       door = doors.Off
                        let text1 = "Состояние автомобиля \(carBrand):  \(ignitionSwitch.rawValue), двери - \(door.rawValue) "
                    print(text1)
                   case .Off :
                       ignitionSwitch = actionIgnation
                       door = doors.On

                    let text2 = "Состояние автомобиля \(carBrand):  \(ignitionSwitch.rawValue), двери - \(door.rawValue) "
                       print(text2)
                   }
        }

}


extension Car {
    func printCar(){
           print ("\(carBrand)  \(carModel) \(yearOfRelease) года выпуска. Двигатель - \(engine.rawValue).")
       }
}







class TrunkCar: OnCar, CustomStringConvertible{
    var description: String
    var carBrand: String
    var carModel: String
    var yearOfRelease: Int
    var engine: engineCar
    var door: doors
    var ignitionSwitch: carIgnition
    var loadCapacity: Int //грузоподъёмность
       var bodyTypeCar: bodyTupe // вид кузова
       var typeOfLoad: String {
           get{
               if bodyTypeCar == .board {
                   return "Осуществляется свободная погрузка"
               }
               if bodyTypeCar == .dumpTruck {
                   return "Осуществляется погрузка через задние ворота"
               }
               if bodyTypeCar == .awing {
                   return "Осуществляется свободная погрузка"
               }
               if bodyTypeCar == .isometric {
                   return "Осуществляется погрузка с помощью системаы мультилифт"
               }
                   return "не возможно выполнить погрузку"
   
           }
   
       }
    
    func action(statusIgnation: carIgnition) {

        if statusIgnation == carIgnition.Off {
            door  = doors.On
            print(" \(ignitionSwitch.rawValue). Двери \(door.rawValue) ")
        } else {
            door = doors.Off
            print(" \(ignitionSwitch.rawValue). Двери \(door.rawValue) ")
        }

    }
    
   
    init(carBrand:String, carModel: String, yearOfRelease: Int, engine: engineCar, door: doors, ignitionSwitch: carIgnition, loadCapacity: Int, bodyTypeCar: bodyTupe, calorCar: String){
            self.carBrand = carBrand
            self.carModel = carModel
            self.yearOfRelease = yearOfRelease
            self.engine = engine
            self.door = door
            self.ignitionSwitch = ignitionSwitch
            self.loadCapacity = loadCapacity
            self.bodyTypeCar = bodyTypeCar
            self.description = calorCar
    }
   
   
       enum bodyTupe: String {
           case board = "Платформа"
           case dumpTruck = "Закрытый цельнометалический"
           case awing = "Тент"
           case isometric = "Изометрический"
       }
    
    func trunkCarPrint() {
        print ("Автомобиль - \(carBrand)  модель - \(carModel) \(yearOfRelease) года выпуска. Двигатель - \(engine.rawValue). || Грузоподъёмноость автомобиля составляет - \(loadCapacity) тонн, Вид борта - \(bodyTypeCar.rawValue), \(typeOfLoad).")

        }
    
}





class SportCar: OnCar, CustomStringConvertible{
    var description: String
    var carBrand: String
    var carModel: String
    var yearOfRelease: Int
    var engine: engineCar
    var door: doors
    var ignitionSwitch: carIgnition
    var maxSpeed: Int
    var acceleration: Double
    var power: Int
 
    func action(statusIgnation: carIgnition) {

        if statusIgnation == carIgnition.Off {
            door  = doors.On
            print(" \(ignitionSwitch.rawValue). Двери \(door.rawValue) ")
        } else {
            door = doors.Off
            print(" \(ignitionSwitch.rawValue). Двери \(door.rawValue) ")
        }

    }
   
    
    init(carBrand:String, carModel: String, yearOfRelease: Int, engine: engineCar, door: doors, ignitionSwitch: carIgnition, max: Int, acceleration: Double, power: Int, description: String){
            self.carBrand = carBrand
            self.carModel = carModel
            self.yearOfRelease = yearOfRelease
            self.engine = engine
            self.door = door
            self.ignitionSwitch = ignitionSwitch
            self.maxSpeed = max
            self.acceleration = acceleration
            self.power = power
            self.description = description
    }
    
    func printSportCar() {
            print ("\(carBrand)  \(carModel) \(yearOfRelease) года выпуска. Двигатель - \(engine.rawValue). || мощность - \(power) л/с, разгон до 100 км/час - \(acceleration) сек.")
        }
    
}













var car1 = Car(carBrand: "Шкода", carModel: "Октавия", yearOfRelease: 2019, engine: .electric, door: .Off, ignitionSwitch: .On)

var carTrunk = TrunkCar(carBrand: "Камаз", carModel: "Неизвестна", yearOfRelease: 2020, engine: .electric, door: .Off, ignitionSwitch: .Off, loadCapacity: 20, bodyTypeCar: .dumpTruck, calorCar: "цвет красный")
var car3 = SportCar(carBrand: "Лада", carModel: "модель неизвестна", yearOfRelease: 2020, engine: .diselEngine, door: .Off, ignitionSwitch: .Off, max: 200, acceleration: 5.5, power: 220, description: "Автомобиль в угоне")




car3.printSportCar()
print(car3.description)
car1.printCar()
carTrunk.trunkCarPrint()
car3.action()
carTrunk.trunkCarPrint()
carTrunk.action()
print(carTrunk.description)
